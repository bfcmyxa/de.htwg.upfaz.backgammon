package de.htwg.upfaz.backgammon.gui;

import java.awt.*;

import javax.swing.*;

import de.htwg.upfaz.backgammon.entities.Field;

public class DrawStones extends JPanel {
	
	final static int border = 30;

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Image stoneb;
	Image stonew;
	Field[] gameMap;

	public DrawStones(Field[] gm) {
		gameMap = gm;

		// Loads the background image and stores in img object.
		stoneb = Toolkit.getDefaultToolkit().createImage("res/stoneb.png");
		stonew = Toolkit.getDefaultToolkit().createImage("res/stonew.png");

	}
	
	private void paintField(final Graphics g, final Image image, final int field) {
		int xCoordinate = 700, yCoordinate;
		
		if (field < 24) {
			xCoordinate -= border;
			xCoordinate -= (field % 12) * 50;
		} else {
		
			switch(field) {
				case 24:
					for (int a = 0; a < gameMap[field].getNumberStones(); a++){
						g.drawImage(image, 340, 35+a*25, null);
					}
					break;
				case 25:
					for (int a = 0; a < gameMap[field].getNumberStones(); a++){
						g.drawImage(image, 340, 575-a*25, null);
					}
					break;
				case 26:
					for (int a = 0; a < gameMap[field].getNumberStones(); a++){
						g.drawImage(image, 690, 35+a*25, null);
					}
					break;
				case 27:
					for (int a = 0; a < gameMap[field].getNumberStones(); a++){
						g.drawImage(image, 690, 575-a*25, null);
					}
					break;
				default:
					break;
			}
		}
		
		if (field < 12) {
			yCoordinate = 30;
			for (int i = 0; i < gameMap[field].getNumberStones(); i++) {
				g.drawImage(image, xCoordinate,yCoordinate + (i * 25),null);
			}
		} else if (field > 11 && field < 24) {
			yCoordinate = 605;
			for (int i = 0; i < gameMap[field].getNumberStones(); i++) {
				g.drawImage(image, xCoordinate,yCoordinate - (i * 25),null);
			}
		}
	}
	
	public void paintComponent(Graphics g) {
		Image imageToDraw;
		for (int i = 0; i < 28; i++) {
			if (gameMap[i].getStoneColor() == 0) {
				imageToDraw = stonew;
			} else {
				imageToDraw = stoneb;
			}
			paintField(g, imageToDraw, i);
		}
	}

}
