package de.htwg.upfaz.backgammon.gui;

import java.awt.*;

import javax.swing.*;


public class Dices extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Image dice1;
	Image dice2;
	Image dice3;
	Image dice4;
	Image dice5;
	Image dice6;
	private Integer[] jumps;
	
	public Dices(Integer[] jumps)
    {
		this.jumps = jumps;
		
        // Loads the background image and stores in img object.
        dice1 = Toolkit.getDefaultToolkit().createImage("res/dice1.png");
        dice2 = Toolkit.getDefaultToolkit().createImage("res/dice2.png");
        dice3 = Toolkit.getDefaultToolkit().createImage("res/dice3.png");
        dice4 = Toolkit.getDefaultToolkit().createImage("res/dice4.png");
        dice5 = Toolkit.getDefaultToolkit().createImage("res/dice5.png");
        dice6 = Toolkit.getDefaultToolkit().createImage("res/dice6.png");
    }
	
	public void paintComponent(Graphics g)
    {
		for(int i = 0; i < 2; i++){
        	try{
        		
        	
        	switch(jumps[i]){
        	case 1:
        		g.drawImage(dice1, 480+i*60, 295, null);
        		break;
        	case 2:
        		g.drawImage(dice2, 480+i*60, 295, null);
        		break;
        	case 3:
        		g.drawImage(dice3, 480+i*60, 295, null);
        		break;
        	case 4:
        		g.drawImage(dice4, 480+i*60, 295, null);
        		break;
        	case 5:
        		g.drawImage(dice5, 480+i*60, 295, null);
        		break;
        	case 6:
        		g.drawImage(dice6, 480+i*60, 295, null);
        		break;
        	default:
        		System.out.println("dafuq?");
        		break;
        	}
        	}catch (Exception e){
        		System.out.println("Dices.paint() - something went wrong");
        		
        	}
        }
    }

}
