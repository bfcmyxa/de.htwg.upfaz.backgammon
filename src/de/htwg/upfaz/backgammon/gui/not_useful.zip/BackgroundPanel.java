package de.htwg.upfaz.backgammon.gui;

import java.awt.*;
import java.awt.Graphics;

import javax.swing.*;

class BackgroundPanel extends JPanel
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// The Image to store the background image in.
    Image background;
    public BackgroundPanel()
    {
        // Loads the background image and stores in img object.
        background = Toolkit.getDefaultToolkit().createImage("res/background.png");
    }

    public void paintComponent(Graphics g)
    {
        // Draws the img to the BackgroundPanel.
        g.drawImage(background, 0, 0, null);
    }
}